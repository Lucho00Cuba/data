#!/bin/bash

wget https://www.apachefriends.org/xampp-files/8.0.0/xampp-linux-x64-8.0.0-2-installer.run
sudo chmod +x xampp-linux-x64-8.0.0-2-installer.run
sudo ./xampp-linux-x64-8.0.0-2-installer.run
rm xampp-linux-x64-8.0.0-2-installer.run
clear
